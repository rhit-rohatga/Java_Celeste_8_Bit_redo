# Milestone Reports

You must complete all milestone reports.
You are expected to complete them on GradeScope
unless otherwise specified by your instructor.

You can see a Sample UML Diagram in this folder.