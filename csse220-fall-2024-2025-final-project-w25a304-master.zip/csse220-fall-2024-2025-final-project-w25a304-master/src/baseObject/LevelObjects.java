package baseObject;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Rectangle2D.Double;
import mainApp.Player;
import mainApp.SuperObject;

/**
 * Class: LevelObjects
 * @author rohatga, cravensbe
 * <br> Purpose: The abstract class inherited by all the classes that block movement
 * <br> Restrictions: 
 * <br> 	It is abstract and thus can't be constructed
 * <br> 	Handles all the collisions for all objects
 * 
 */
public abstract class LevelObjects extends SuperObject {
	public static final int YSCALING_FACTOR = 9;
	private static final int XSCALING_FACTOR = 4;
	
	/**
	 * gives the rectangle to SuperObject to store
	 * @param rectangle
	 */
	public LevelObjects(Rectangle2D.Double rectangle) {
		super(rectangle);
	}
	
	/**
	 * MAIN COLLISIONS METHOD
	 * @param player
	 * <br> Creates the intersection of the players rectangle and the given objects rectangle
	 * <br> Adjusts the position of the player based in its current position and the dimensions of the intersection rectangle
	 * <br> Restrictions: 
	 * <br> 	doesn't work on cloud
	 * <br>		has a small bug with multiple wall collisions
	 * @throws MyException
	 * <br> Throws the exception if the player glitches though a wall
	 * <br> Throws the exception if collisions were detected incorrectly
	 * 
	 * Only TicksInWallJump and setJump were implemented by Ben, ie 6 lines;
	 */
	public void fixPlayerPos(Player player) {
		
		try {
			Rectangle2D.Double myRect = super.getRectangle();
			Rectangle2D.Double playerRect = player.getPlayerRect();
			Rectangle2D.Double colisionRect = (Double) myRect.createIntersection(playerRect);
			double width = colisionRect.width;
			double height = colisionRect.height;
			if (width >= height) {
				if (playerRect.getMaxY() > myRect.getMaxY()) {
					if(player.getTicksInWallJump()<=8) {
						player.setPosY(myRect.getMaxY());
						player.setVelY(0);
					}
				} else if (playerRect.getMaxY() < myRect.getMaxY()) {
					player.setPosY(myRect.getMinY() - playerRect.height - YSCALING_FACTOR);
					player.canJump();
					if(player.getNumDashes()<1) {
						player.addDash();
					}
				}
			} else if (width < height) {
				if(player.getTicksInWallJump()<=5) {
					if (playerRect.getMaxX() > myRect.getMaxX()) {
						player.setPosX(myRect.getMaxX() + XSCALING_FACTOR);
						player.setJumpRight();
						player.setVelY(0);
					} else if (playerRect.getMaxX() < myRect.getMaxX()) {
						player.setPosX(myRect.getMinX() - playerRect.width - XSCALING_FACTOR);
						player.setJumpLeft();
						player.setVelY(0);
					}
				}
			}else {
				throw new MyException();
			}
		}catch( MyException a) {
			a.getMessage();
		}
	}
	
	/**
	 * Is required for the different functionality of each type of LevelObject
	 * Tells the subclasses that they have to implement their own functionality of collides with.
	 */
	public abstract void collideWithPlayer(Player player);
	
	/**
	 * Exists in case a class forgets to override the drawOn method
	 *@param Graphics2D 
	 * requires the graphics from JComponent to draw.
	 */
	@Override
	public void drawOn(Graphics2D g) {
		super.drawOn(g);
	}
}
