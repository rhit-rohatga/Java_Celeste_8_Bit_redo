package baseObject;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import mainApp.Player;
/**
 * Class: Block
 * @author rohatga
 * <br> Purpose: The main game building block,
 * <br> It is a rectangle with inputed dimensions
 * <br> Restrictions: Can't be used to create the special game blocks
 */
public class Block extends LevelObjects{

/**
 * Same as all the other objects in the game, takes and stores a rectangle for its position
 * @param rect
 */		
	public Block( Rectangle2D.Double rect) {
		super(rect);
	}
	
	/**
	 * Draws the block
	 *@param Graphics2D 
	 * requires the graphics from JComponent to draw.
	 */
	public void drawOn(Graphics2D g) {
		g.setColor(Color.blue);
		super.drawOn(g);
	}
	/**
	 * Handles collision by calling the main collisions method in LevelObjects
	 * Is called by the doesCollide method in SuperObject
	 */
	@Override
	public void collideWithPlayer(Player player) {
		if(super.getRectangle().intersects(player.getPlayerRect())){
			super.fixPlayerPos(player);
		}
	}
}