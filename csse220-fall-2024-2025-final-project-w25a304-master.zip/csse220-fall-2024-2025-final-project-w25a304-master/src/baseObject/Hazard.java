package baseObject;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import mainApp.Player;

/**
 * Class: Hazard
 * @author rohatga
 * <br> Purpose: The main damage dealing obstacle
 * <br> It is a rectangle with inputed dimensions
 * <br> Restrictions:
 * <br> 	 Kills the player
 * <br> 	 Has different dimensions than all the other gameObjects
 */
public class Hazard extends LevelObjects{
	
	/**
	 * Same as all the other objects in the game, takes and stores a rectangle for its position
	 * @param rect
	 */
	public Hazard(Rectangle2D.Double rectangle) {
		super(rectangle);
	}
	
	/**
	 * Draws the block
	 *@param Graphics2D 
	 * requires the graphics from JComponent to draw.
	 */
	@Override
	public void drawOn(Graphics2D g) {
		g.setColor(Color.red);
		super.drawOn(g);
	}

	/**
	 * Handles collision by calling the main collisions method in LevelObjects
	 * Is called by the doesCollide method in SuperObject
	 * Added an implementation for if the player has a greater health, not used anywhere, just a possibility
	 * <br> Restrictions:
	 * <br> 	Kills the player if he has <=1 health
	 */
	@Override
	public void collideWithPlayer(Player player) {
		if(super.getRectangle().intersects(player.getPlayerRect())){
			super.fixPlayerPos(player);
			if(player.getHealth() <= 1) {
				 player.kill();
			}else {
				player.setHealth(player.getHealth()-1);
			}
		}
		
	}

}
