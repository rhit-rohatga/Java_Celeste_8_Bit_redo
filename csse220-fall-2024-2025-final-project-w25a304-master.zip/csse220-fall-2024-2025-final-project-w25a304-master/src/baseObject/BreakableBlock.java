package baseObject;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import mainApp.Player;
/**
 * Class: BreakableBlock
 * @author rohatga, cravenbe
 * <br> Purpose: Its a block that breaks if hit with a dash by the player
 * <br> It is a rectangle with inputed dimensions
 * <br> Restrictions: 
 */
public class BreakableBlock extends LevelObjects{
	private boolean hasBroken = false;
	
	public BreakableBlock(Rectangle2D.Double rectangle) {
		super(rectangle);
		
	}
	/**
	 * <br>Handles collision by calling the main collisions method in LevelObjects
	 * <br>Is called by the doesCollide method in SuperObject
	 * <br> Restrictions: 
	 * <br>		Since the object can break it needs special conditions so it doesn't collide with player after breaking
	 * @param boolean hasBroken
	 * <br> 	These restrictions are created by the parameter hasBroken
	 */	
	@Override
	public void collideWithPlayer(Player player) {
		if(this.hasBroken == false) {
			super.fixPlayerPos(player);
		}
		if(player.getTicksInDash() > 0) {
			hasBroken = true;
		}
	}
	
	/**
	 * <br>Draws the block
	 *@param Graphics2D 
	 * <br>requires the graphics from JComponent to draw.
	 * <br> Restrictions:
	 * <br>		Since we dont want to draw a broken block, we use the hasBroken field to detect when its broken
	 */
	@Override
	public void drawOn(Graphics2D g) {
		if(!this.hasBroken) {
			g.setColor(Color.cyan);
			super.drawOn(g);
		}
	}

}

