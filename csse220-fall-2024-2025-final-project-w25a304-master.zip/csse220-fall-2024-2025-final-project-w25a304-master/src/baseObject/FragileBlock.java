package baseObject;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import mainApp.Player;

/**
 * Class: FragileBlock
 * @author rohatga
 * <br> Purpose: The main breakable block in the game
 * <br> It is a rectangle with inputed dimensions
 * <br> Restrictions: 
 * <br> 	breaks after 50 game ticks
 * <br> 	only starts breaking after player collides with it
 */

public class FragileBlock extends LevelObjects{
	public static final int TIME_TO_BREAK = 50;
	public static final int TIME_TO_RETURN =100;
	private boolean isBreaking = false;
	private int breakTimer = TIME_TO_BREAK;;
	private boolean hasBroken = false;
	private int returnTimer;
	
	
	/**
	 * Same as all the other objects in the game, takes and stores a rectangle for its position
	 * @param rect
	 */
	public FragileBlock(Rectangle2D.Double rectangle) {
		super(rectangle);
	}
	/**
	 * <br>Draws the block
	 *@param Graphics2D 
	 * <br> requires the graphics from JComponent to draw.
	 * <br> Restrictions: 
	 * <br> 	Only draws the object when it hasn't broken
	 * <br> 	Also contains the counter for when the object breaks, and when it comes back
	 */
	public void drawOn(Graphics2D g) {
		if(!this.hasBroken) {
			g.setColor(Color.orange);
			super.drawOn(g);
		}else {
			this.returnTimer--;
			if(this.returnTimer <=0) {
				this.hasBroken = false;
			}
		}
		if(this.isBreaking) {
			breakTimer--;
			if(breakTimer < 0) {
				this.isBreaking = false;
				this.hasBroken  = true;
				this.breakTimer =TIME_TO_BREAK;
				this.returnTimer = TIME_TO_RETURN;
			}
		}
	}
	/**
	 * Handles collision by calling the main collisions method in LevelObjects
	 * Is called by the doesCollide method in SuperObject
	 */
	@Override
	public void collideWithPlayer(Player player) {
		if(super.getRectangle().intersects(player.getPlayerRect()) && !this.hasBroken){
			super.fixPlayerPos(player);
			isBreaking = true;
			if(!isBreaking) {
				this.breakTimer = TIME_TO_BREAK;
			}
		}
	}
}
