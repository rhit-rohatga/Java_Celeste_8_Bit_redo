package baseObject;

/**
 * Class: BankAccount
 * @author rohatga
 * <br>Purpose: Used to detect errors in collisions
 * <br>Restrictions: 
 * <br> 	Is only ever thrown by LevelObject
 * <br> 	Currently only prints a system.err line.
 *  * <br>For example: 
 * <pre>
 *    system.err.println("Collision Error Detected: Still needs fixing");
 * </pre>
 */
public class MyException extends Exception {
	
	/**
	 * returns the updated StringMessage for the user to use
	 * @return String
	 */
	@Override
	public String getMessage() {
		return "Collision Error Detected: Still needs fixing";
	}
	
}
