package baseObject;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import mainApp.Player;
/**
 * Class: Cloud
 * @author rohatga
 * <br> Purpose: Acts as a moving platform
 * <br> It is a rectangle with inputed dimensions
 * <br> Restrictions: doesn't collide with the player if player is below or on either side of cloud
 */

public class Cloud extends LevelObjects{
	private static final int CLOUD_VELOCITY = 3;
	private int velX = CLOUD_VELOCITY;
	
	/**
	 * Same as all the other objects in the game, takes and stores a rectangle for its position
	 * @param rect
	 */
	public Cloud(Rectangle2D.Double rectangle) {
		super(rectangle);
	}
/**
 * Has its own unique collideWithPlayer method due to its Restrictions
 * This method is still called by the SuperObject doesCollide Method.
 */
	@Override
	public void collideWithPlayer(Player player) {
		Rectangle2D.Double playerRect = player.getPlayerRect();
		Rectangle2D.Double myRect = getRectangle();
		if (playerRect.getCenterY() < myRect.getMinY()) {
				player.setPosY(myRect.getMinY() - playerRect.height - LevelObjects.YSCALING_FACTOR);
				player.canJump();
				player.setVelX(player.getVelX()+velX);
				if(player.getNumDashes()<1) {
					player.addDash();
				}
			}
		
		
	}
/**
 * Since cloud is a moving object it has an updatePos method that updates it's position each tick
 * the updatePos method is called by the GameComponent class
 */
	public void updatePos() {
		super.addX(this.velX);
		super.isOffScreen();
	}
	/**
	 * Draws the cloud
	 *@param Graphics2D 
	 * requires the graphics from JComponent to draw.
	 */
	@Override
	public void drawOn(Graphics2D g) {
		g.setColor(Color.ORANGE);
		g.draw(getRectangle());
		g.fill(getRectangle());
	}
/**
 * Sets the cloud velocity depending on whether it is a left moving or right moving cloud
 * method is called by Overlay
 */
	public void setVelX() {
		this.velX = -this.velX;
		
	}
}
