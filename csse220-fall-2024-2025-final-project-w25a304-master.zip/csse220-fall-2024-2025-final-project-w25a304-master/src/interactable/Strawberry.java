package interactable;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import mainApp.Player;
import mainApp.PointCounter;

/**
 * Class: Strawberry
 * @author rohatga
 * <br> Purpose: Collect to add points,
 * <br> It is a rectangle with inputed dimensions
 * <br> Restrictions: 
 * <br> 	Can't be consumed multiple times
 * <br> 	Has a fixed amount of points given
 */
public class Strawberry extends Interactable{
	private static final int POINTS = 1000;
	private boolean hasCollected = false;
	private PointCounter pointCounter;

	/**
	 * @param rect
	 *  takes and stores a rectangle for its position
	 * @param PointCounter
	 *  stores and communicates point totals
	 */	
	public Strawberry(Rectangle2D.Double rectangle, PointCounter pointAdder) {
		super(rectangle);
		this.pointCounter = pointAdder;
	}

	/**
	 * Uses the PointCounter Class to keep track of points
	 * hasCollected ensures that it is only consumed once
	 * Is called by the doesCollide method in SuperObject
	 */
	@Override
	public void collideWithPlayer(Player player) {
		if(!this.hasCollected) {
			this.pointCounter.addPoints(POINTS);
			System.out.println("Added " + POINTS + " points");
			this.pointCounter.printPoints();
		}
		hasCollected = true;
	}
	
	/**
	 * Draws the block
	 *@param Graphics2D 
	 * requires the graphics from JComponent to draw.
	 * <br> Restrictions: 
	 * <br> 	Only draws when the balloon hasn't collided
	 * <br> 	Never resets
	 */
	@Override
	public void drawOn(Graphics2D g) {
		if(!hasCollected) {
			g.setColor(Color.pink);
			super.drawOn(g);
		}
	}

}
