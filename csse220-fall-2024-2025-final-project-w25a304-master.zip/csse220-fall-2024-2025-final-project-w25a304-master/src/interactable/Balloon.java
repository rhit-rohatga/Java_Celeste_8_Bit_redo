package interactable;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import mainApp.Player;

/**
 * Class: Balloon
 * @author rohatga
 * <br> Purpose: Collect to add a dash to player,
 * <br> It is a rectangle with inputed dimensions
 * <br> Restrictions: 
 * <br> 	Can be used multiple times
 * <br> 	Has a cooldown of 40 ticks
 */
public class Balloon extends Interactable{
	private boolean hasCollided = false;
	private static final int TIME_TO_RETURN = 40;
	private int returnTimer = TIME_TO_RETURN;

	/**
	 * Same as all the other objects in the game, takes and stores a rectangle for its position
	 * @param rect
	 */	
	public Balloon(Rectangle2D.Double rectangle) {
		super(rectangle);
	}
	
	/**
	 * Handles functionality of the object
	 * Is called by the doesCollide method in SuperObject
	 */
	@Override
	public void collideWithPlayer(Player player) {
		if(!this.hasCollided) {
			player.addDash();
			this.hasCollided = true;
		}
	}
	
	/**
	 * Draws the block
	 *@param Graphics2D 
	 * requires the graphics from JComponent to draw.
	 * <br> Restrictions: 
	 * <br> 	Only draws when the balloon hasn't collided
	 * <br> 	Restarts drawing after 40 ticks
	 */
	public void drawOn(Graphics2D g) {
		if(!this.hasCollided) {
			g.setColor(Color.darkGray);
			super.drawOn(g);	
		}else {
			this.returnTimer--;
			if(this.returnTimer < 0) {
				this.hasCollided = false;
				this.returnTimer = TIME_TO_RETURN;
			}
		}
			
	}
}