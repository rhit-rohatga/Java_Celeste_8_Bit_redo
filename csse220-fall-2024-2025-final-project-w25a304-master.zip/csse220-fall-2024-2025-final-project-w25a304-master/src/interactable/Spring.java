package interactable;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import mainApp.Player;

/**
 * Class: Spring
 * @author rohatga
 * <br> Purpose: Makes the player 'spring up' ie increases its velocity temporarily
 * <br> It is a rectangle with inputed dimensions
 * <br> Restrictions: 
 * <br> 	Can be colided with on any side and only increase vertical velocity
 */
public class Spring extends Interactable{
	private int SPRING_VELOCITY = 20;
	private static final Color COLOR = Color.gray;
	
	/**
	 * Same as all the other objects in the game, takes and stores a rectangle for its position
	 * @param rect
	 */		
	public Spring(Rectangle2D.Double rectangle) {
		super(rectangle);
		
	}
	
	/**
	 * Draws the block
	 *@param Graphics2D 
	 * requires the graphics from JComponent to draw.
	 */
	@Override
	public void drawOn(Graphics2D g) {
		g.setColor(COLOR);
		super.drawOn(g);
	}

	/**
	 * Handles functionality of the object
	 * Is called by the doesCollide method in SuperObject
	 * Adds a dash to the player if he has none
	 */
	@Override
	public void collideWithPlayer(Player player) {
		player.setVelY(-SPRING_VELOCITY);
		if(player.getNumDashes()==0) {
			player.addDash();
		}
	} 

}
