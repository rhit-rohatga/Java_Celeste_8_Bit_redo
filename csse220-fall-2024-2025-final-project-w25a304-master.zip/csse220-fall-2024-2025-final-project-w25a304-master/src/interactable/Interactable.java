package interactable;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import mainApp.Player;
import mainApp.SuperObject;

/**
 * Class: Interactable
 * @author rohatga
 * <br> Purpose: The abstract class inherited by all the classes that buff the player
 * <br> Restrictions: 
 * <br> 	It is abstract and thus can't be constructed
 * <br> 	Mainly functions as a connector for all Interactable objects and the class SuperObject
 * 
 */
public abstract class Interactable extends SuperObject{

	/**
	 * gives the rectangle to SuperObject to store
	 * @param rectangle
	 */
	public Interactable(Rectangle2D.Double rectangle) {
		super(rectangle);
	}
	
	/**
	 * Is required for the different functionality of each type of Interactables
	 * Tells each subclass that it needs a seperate implementation of what it does upon collision
	 */
	public abstract void collideWithPlayer(Player player);
	
	/**
	 * Exists in case a class forgets to override the drawOn method
	 *@param Graphics2D 
	 * requires the graphics from JComponent to draw.
	 */
	public void drawOn(Graphics2D g) {
		super.drawOn(g);
	}
}
