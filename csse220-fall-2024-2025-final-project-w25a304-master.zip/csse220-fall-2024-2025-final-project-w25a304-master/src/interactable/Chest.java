package interactable;
import java.awt.geom.Rectangle2D;
import mainApp.Player;

/**
 * Class: Chest
 * @author cravenbe
 * Not implemented due to time restriction and coupling issues with key and strawberry
 */
public class Chest extends Interactable{
	private Key key;
	public Chest(Rectangle2D.Double rectangle) {
		super(rectangle);
	}	
	/**
	 * not implemented
	 */
	@Override
	public void collideWithPlayer(Player player/*, boolean hasKey*/) {
//		if(hasKey == true) {
//
//		}
		//method should check if player has the key when it collides then decide functionality that way
		//we could also do it so that chest becomes a strawberry
	}
	/**
	 * not implemented
	 */
	public void isOpened() {
		//Put a strawberry where this chest is
	}
}
