package interactable;
import java.awt.geom.Rectangle2D;

import mainApp.PointCounter;

/**
 * Class: FlyingStrawberry
 * @author cravenbe
 * Not implemented.
 * 
 */
public class FlyingStrawberry extends Strawberry{
	
	/**
	 * If it was implemented
	 * @param rect
	 *  takes and stores a rectangle for its position
	 * @param PointCounter
	 *  stores and communicates point totals
	 */	
	public FlyingStrawberry(Rectangle2D.Double rectangle, PointCounter adder) {
		super(rectangle, adder);
		// TODO Auto-generated constructor stub
	}
	/**
	 * If implemented
	 * Moves the strawberry if the player dashes
	 */
	public void hasDashed() {
		if(true) {
			// code to change the position of the strawberry
		}
	}

}
