package interactable;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import mainApp.Player;

/**
 * Class: Chest
 * @author cravenbe
 * Not implemented due to time restriction and coupling issues with key and strawberry
 */
public class Key extends Interactable{

	/**
	 * Same as all the other objects in the game, takes and stores a rectangle for its position
	 * @param rect
	 */	
	public Key(Rectangle2D.Double rectangle) {
		super(rectangle);
	}
	
	
	@Override
	public void collideWithPlayer(Player player) {
			unlockChest();
	}
	
	public boolean unlockChest() {
		return true;
	}
	
	@Override
	public void drawOn(Graphics2D g) {
		g.setColor(Color.yellow);
	}

}
