package mainApp;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.Timer;

import mainApp.GameListeners.GameAdvanceListener;
import mainApp.GameListeners.LevelSelectListener;
import mainApp.GameListeners.MovementListener;

//github.com/rhit-csse220/csse220-fall-2024-2025-final-project-w25a304

/**
 * Class: MainApp
 * @author W25A304
 * <br>Purpose: Top level class for CSSE220 Project containing main method 
 * <br>Restrictions: None
 */
public class MainApp {
	public static final int DELAY = 20;
	public static final int WIDTH = 750;
	public static final int HEIGHT = 750;
	private GameAdvanceListener gameUpdateListener;
	private MovementListener PlayerListener;
	private LevelSelectListener levelSelector;
	private GameListeners allListeners;
	private JFrame frame;
	/**
	 * Uses the Default Constructor
	 */
	
	
	/**
	 * Initializes the game:
	 * 			Makes the frame and sets its parameters (exit on close, size)
	 * 			makes a new component and adds it to the frame
	 * 			creates the listeners and adds them to their respective places
	 * 			creates a timer and adds the gameUpdateListener to it
	 * 			starts the timer
	 * 			sets the frame to visible
	 */
	private void runApp() {
		this.frame = new JFrame("Arcade Game");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(WIDTH, HEIGHT);
		GameComponent component = new GameComponent();
		frame.add(component);
		this.allListeners = new GameListeners(component);
		this.levelSelector = allListeners.makeLevelListener();
		this.gameUpdateListener = allListeners.makeTimeListener();
		this.PlayerListener = allListeners.makeKeyListener();
		this.frame.addKeyListener(this.PlayerListener);
		this.frame.addKeyListener(this.levelSelector);
		Timer timer = new Timer(DELAY, this.gameUpdateListener);
		timer.start();
		frame.setVisible(true);
	}

	/**
	 * ensures: runs the application
	 * @param args unused
	 */
	public static void main(String[] args) {
		MainApp mainApp = new MainApp();
		mainApp.runApp();		
	}
}