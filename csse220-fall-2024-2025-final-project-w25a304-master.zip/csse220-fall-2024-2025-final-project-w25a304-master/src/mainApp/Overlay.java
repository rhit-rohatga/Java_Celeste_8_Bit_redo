package mainApp;
import java.awt.geom.Rectangle2D;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.System.Logger.Level;
import java.util.ArrayList;
import java.util.Scanner;
import interactable.Balloon;
import interactable.Interactable;
import interactable.Spring;
import interactable.Strawberry;
import baseObject.Block;
import baseObject.BreakableBlock;
import baseObject.Cloud;
import baseObject.FragileBlock;
import baseObject.Hazard;
import baseObject.LevelObjects;

/**
 * Class: Overlay
 * @author rohatga, cravenbe
 * <br> Purpose: 
 * 		Create all the instances of all the game objects and the player onto their respective positions on the screen
 * <br> Restrictions: 
 * <br> 	Can't draw anything
 * <br> 	Defines the screen pixel sizes and object dimensions
 * <br> 	reads and draws from text files
 *
 */
public class Overlay {
	private static final int X_BLOCKS = 16;
	private static final int Y_BLOCKS = 16;
	public static final int X_POS_SHIFT = MainApp.WIDTH / X_BLOCKS;
	public static final int Y_POS_SHIFT = MainApp.HEIGHT / Y_BLOCKS;
	private static final int CLOUD_SIZE_REDUCTION =20;
	private static final int HAZARDSHIFT = 15;
	private ArrayList<String> LevelSelector;
	private ArrayList<LevelObjects> blocks;
	private ArrayList<Interactable> interactables;
	private int xPos;
	private int yPos;
	private int index;
	private GameComponent component;
	private ArrayList<Cloud> clouds;
	private Scanner scanner;
	private PointCounter pointAdder;

	public Overlay(GameComponent component) {
		this.LevelSelector = new ArrayList<String>();
		LevelSelector.add("Level1.txt");
		LevelSelector.add("Level2.txt");
		LevelSelector.add("Level3.txt");
		LevelSelector.add("Level4.txt");
		LevelSelector.add("Level5.txt");
		LevelSelector.add("Level6.txt");
		LevelSelector.add("Level7.txt");
		LevelSelector.add("Level8.txt");
		LevelSelector.add("Level9.txt");
		LevelSelector.add("Level10.txt");
		LevelSelector.add("LevelFinal2.txt");
		this.component = component;
		this.pointAdder = new PointCounter();
	}
	
/**
 * Purpose: 
 * 		Create lists of all the objects in their respective positions on the level
 * 		Sends the lists to GameComponent to be drawn
 * Called each time a level is completed, each time the player dies, or when the n or p keys are pressed
 * @param string
 * @throws FileNotFoundException
 */
	public void loadLevel(String string) throws FileNotFoundException {
		this.blocks = new ArrayList<LevelObjects>();
		this.interactables = new ArrayList<Interactable>();
		this.clouds = new ArrayList<Cloud>();
		try {
			if(string == "") {
				FileReader file = new FileReader(LevelSelector.get(this.index));
				this.scanner = new Scanner(file);
			}else {
				FileReader file = new FileReader("SpecialLevel.txt");
				this.scanner = new Scanner(file);
			}
			
			
			for (int y = 0; y < Y_BLOCKS; y++) {
				yPos = y * Y_POS_SHIFT;
				for (int x = 0; x < X_BLOCKS; x++) {
					xPos = x * X_POS_SHIFT;

					String next = scanner.next();

					if (next.equals("B")) {
						Block block = new Block(new Rectangle2D.Double(xPos, yPos, X_POS_SHIFT, Y_POS_SHIFT));
						this.blocks.add(block);
					} else if (next.equals("^")) {
						Hazard hazard = new Hazard(
								new Rectangle2D.Double(xPos, yPos + HAZARDSHIFT, X_POS_SHIFT, Y_POS_SHIFT -HAZARDSHIFT));
						this.blocks.add(hazard);
					} else if (next.equals("<")) {
						Hazard hazard = new Hazard(
								new Rectangle2D.Double(xPos + HAZARDSHIFT, yPos, X_POS_SHIFT - HAZARDSHIFT, Y_POS_SHIFT));
						this.blocks.add(hazard);
					} else if ( next.equals(">")) {
						Hazard hazard = new Hazard(
								new Rectangle2D.Double(xPos, yPos, X_POS_SHIFT - HAZARDSHIFT, Y_POS_SHIFT));
						this.blocks.add(hazard);
					} else if (next.equals("v")) {
						Hazard hazard = new Hazard(
								new Rectangle2D.Double(xPos, yPos, X_POS_SHIFT, Y_POS_SHIFT - HAZARDSHIFT));
						this.blocks.add(hazard);
					}else if (next.equals("F")) {
						FragileBlock fragileBlock = new FragileBlock(
								new Rectangle2D.Double(xPos, yPos, X_POS_SHIFT, Y_POS_SHIFT));
						this.blocks.add(fragileBlock);
					} else if (next.equals("*")) {
						Player player = new Player(
								new Rectangle2D.Double(xPos + 10, yPos + 5, X_POS_SHIFT - 20, Y_POS_SHIFT - 10));
						this.component.setPlayer(player);
					} else if (next.equals("T")) {
						Spring spring = new Spring(new Rectangle2D.Double(xPos, yPos, X_POS_SHIFT, Y_POS_SHIFT));
						this.interactables.add(spring);
					} else if(next.equals("?")) {
						Balloon balloon = new Balloon(new Rectangle2D.Double(xPos, yPos, X_POS_SHIFT, Y_POS_SHIFT));
						this.interactables.add(balloon);
					} else if(next.equals("#")) {
						BreakableBlock breakableBlock = new BreakableBlock(
								new Rectangle2D.Double(xPos, yPos, X_POS_SHIFT, Y_POS_SHIFT));
						this.blocks.add(breakableBlock);
					} else if(next.equals("s")) {
						Strawberry strawberry = new Strawberry(
								new Rectangle2D.Double(xPos, yPos, X_POS_SHIFT, Y_POS_SHIFT), this.pointAdder);
						this.interactables.add(strawberry);
					} else if(next.equals("R")) {
						Cloud cloud = new Cloud(
								new Rectangle2D.Double(xPos, yPos + CLOUD_SIZE_REDUCTION, X_POS_SHIFT, Y_POS_SHIFT - CLOUD_SIZE_REDUCTION));
						this.clouds.add(cloud);
					} else if(next.equals("L")) {
						Cloud cloud = new Cloud(
								new Rectangle2D.Double(xPos, yPos + CLOUD_SIZE_REDUCTION, X_POS_SHIFT, Y_POS_SHIFT - CLOUD_SIZE_REDUCTION));
						cloud.setVelX();
						this.clouds.add(cloud);
					}
				}
			}
			scanner.close();
			this.component.setblockList(this.blocks);
			this.component.setInteractables(interactables);
			this.component.setCloudList(this.clouds);
		} catch (IndexOutOfBoundsException a) {
			System.err.println("NO SUCH FILE EXISTS:");
			System.err.println("    Are you trying to find a secret level?");
			System.err.println("    Are you trying to go past the last level?");
			System.err.println("Please dont...");
			this.index = 10;
		} catch (FileNotFoundException a) {
			System.err.println("NO SUCH FILE EXISTS:");
			System.err.println("    Are you trying to find a secret level?");
			System.err.println("    Are you trying to go back from the first level?");
			System.err.println("Please dont...");
			this.index = 0;
		}

	}
	
	/**
	 * resets the level when the player dies
	 * only called when the player hits a hazard, or when the player falls out the bottom of the map
	 */
	public void reload() {
		try {
			this.loadLevel("");
		} catch (FileNotFoundException e) {
			System.err.println("FILE NOT FOUND: Issue in code: to fix");
		}
	}
	
	/**
	 * loads the next level in the list
	 * Only called when the n key is pressed or when the player completes a level
	 */
	public void toNextLevel() {
		this.index++;
		try {
			this.loadLevel("");
		} catch (FileNotFoundException e) {
			System.err.println("FILE NOT FOUND: Issue in code: to fix");
		}
	}

	/**
	 * loads the previous level in the list
	 * Only called when the p key is pressed
	 */
	public void toPreviousLevel() {
		this.index--;
		try {
			this.loadLevel("");
		} catch (FileNotFoundException e) {
			System.err.println("FILE NOT FOUND: Issue in code: to fix");
		}
	}
	
	/**
	 * Getter for the level information
	 * @return
	 */
	public int getIndex() {
		return index;
	}

	/**
	 * Loads the special level when the player goes though the first set of breakable blocks
	 * Called from the GameListeners class. 
	 */
	public void loadSpecialLevel() {
		try {
			this.loadLevel("SpecialLevel");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
	

