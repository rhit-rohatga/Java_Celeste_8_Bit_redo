package mainApp;

/**
 * Class PointCounter
 * @author rohatga
 * Purpose: 
 * 		Tally and print points
 * Restrictions:
 * 		None
 */
public class PointCounter {
	private int points = 0;
	
	/**
	 * Default Constructor
	 */
	
	/**
	 * Adds the given points to the total points gained in this game
	 * @param toAdd
	 */
	public void addPoints(int toAdd) {
		this.points += toAdd;
	}

	/**
	 * Prints the total number of points gained by the player till now in the game
	 */
	public void printPoints() {
		System.out.println("Current total points: " + this.points);
	}
	
}
