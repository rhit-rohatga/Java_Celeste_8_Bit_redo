package mainApp;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

/**
 * Class: Player
 * @author rohatga, cravenbe
 * <br> Purpose: to not go through blocks, die, or loose faith in the game as it goes on
 * <br> Restrictions: 
 * <br> 	Most of it is getters 
 * <br> 	Doesn't create the level
 * <br> 	Creates an instance of the Overlay class to load the game.
 * <br> 	Loads the first level instantly upon being created 
 * <br> 	Updates and draws the game once every tick
 */
public class Player {
	private Rectangle2D.Double playerRect;
	private int health;
	private int numDashes =1;
	private int velX;
	private int velY;
	private int posX;
	private int posY;
	private int ticksLeftInDash = 0;
	private int dashYVel = 0;
	private double width;
	private double height;
	private boolean hasDied = false;
	private boolean canJump = false;
	private boolean level = false;
	private boolean canJumpRight;
	private boolean canJumpLeft;
	private int ticksLeftInWallJump = 0;
	private int walljumpVelModifier = 0;
	
	private static final int ACCELERATION_DUE_TO_GRAVITY = 1;
	private static final int DASH_VELOCITY = 12;
	private static final int PLAYER_VELOCITY = 5;
	private static final int JUMP_VELOCITY = 16;
	private static final int MAX_VELOCITY = 10;
	private static final int TICKS_TO_DASH = 10;
	private static final int TICKS_IN_WALLJUMP = 10;
	private static final int WALLJUMP_VEL_MODIFIER = 8;
	

	/**
	 * Default constructor for all the game objects
	 * but this one stores the x, y positions along with width and height of the rectangle to do movement and collisions
	 * @param rectangle
	 */
	public Player(Rectangle2D.Double rectangle) {
		this.posX = (int)rectangle.getX();
		this.posY = (int)rectangle.getY();
		this.playerRect = rectangle;
		this.width = rectangle.width;
		this.height = rectangle.height;
	}
	/**
	 * Checks if the player is offScreen and fixes its position if it is.
	 * In addition, it contains the level completion and death conditions inbuilt
	 * By changing the boolean values it activates the conditionals that relate to each of these conditions in GameListener.
	 */
	public void isOffScreen() {
		if(this.posX <0) {
			this.posX = 0;
		}
		if(this.posY <0) {
			this.posY = 0;
			this.level  = true;
		}
		if(this.posX + width >= MainApp.WIDTH) {
			this.posX = (int) (MainApp.WIDTH - this.width);
		}
		if(this.posY + height >= MainApp.HEIGHT) {
			this.posY = (int) (MainApp.HEIGHT - 2*height);
			this.hasDied = true;
		}
	}
	
	/**
	 * Draws the player
	 *@param Graphics2D 
	 * requires the graphics from JComponent to draw.
	 */
	public void drawOn(Graphics2D g2) {
		if(numDashes >=1) {
			g2.setColor(Color.MAGENTA);
		}else {
			g2.setColor(Color.PINK);
		}
		this.updatePlayerRect();
		g2.fill(playerRect);
	}
	/**
	 * Checks dash conditions, and then updates the position based on given velocities.
	 */
	public void updatePos() {
		if(ticksLeftInDash == 0) {
			if(this.velY<MAX_VELOCITY) {
				this.velY += ACCELERATION_DUE_TO_GRAVITY;
			}
		}else {
			this.velY = this.dashYVel;
		}
		
		this.posX += this.velX;
		this.posY += this.velY;
		this.isOffScreen();
	}
	
	/**
	 * Fixes the bugs with wall jumping
	 * Uses ticks to keep the player moving in the jump direction, even after it leaves the wall
	 */
	public void jump() {
		if(this.canJumpLeft == true) {
			walljumpVelModifier = -WALLJUMP_VEL_MODIFIER;
			this.velY = (int) (-JUMP_VELOCITY);
			this.ticksLeftInWallJump = TICKS_IN_WALLJUMP;
			this.canJumpLeft = false;
		}else if(this.canJumpRight == true) {
			walljumpVelModifier = WALLJUMP_VEL_MODIFIER;
			this.velY = (int) (-JUMP_VELOCITY);
			this.ticksLeftInWallJump = TICKS_IN_WALLJUMP;
			this.canJumpRight = false;
		}else if(this.canJump == true) {
			this.velY = -JUMP_VELOCITY;
			this.canJump = false;
		}
	}
	
	/**
	 * Activates a dash
	 */
	public void dashHandler() {
		this.numDashes--;
		this.ticksLeftInDash = TICKS_TO_DASH;
	}
	
	/**
	 * Checks which x direction the player is moving in 
	 * @return String direction
	 */
	public String directionOfXMovement() {
		if(this.velX > 0) {
			return "right";
		} else if(this.velX < 0) {
			return "left";
		}else {
			return null;
		}
	}
	
	/**
	 * sets the players velocity depending on whether it is still affected by the jump method
	 */
	public void moveLeft() {
		if(ticksLeftInWallJump == 0) {
			this.velX = -PLAYER_VELOCITY;
			walljumpVelModifier = 0;
		}else {
		this.velX = -PLAYER_VELOCITY/5 + walljumpVelModifier;
		}
	}
	
	/**
	 * sets the players velocity depending on whether it is still affected by the jump method
	 */
	public void moveRight() {
		if(ticksLeftInWallJump == 0) {
			this.velX = PLAYER_VELOCITY;
			walljumpVelModifier = 0;
		}else {
			this.velX = PLAYER_VELOCITY/5 + walljumpVelModifier;
		}
	}
	
	/**
	 * Checks if the player can still dash
	 */
	public void ticksHandler() {
		if(this.ticksLeftInDash > 0) {
			this.ticksLeftInDash --;
		}
		if(this.ticksLeftInWallJump > 0) {
			this.ticksLeftInWallJump --;
		}
	}
	
	/**
	 * Updates the players rectangle for the new positions before it is drawn by the GameComponent
	 */
	
	public void updatePlayerRect() {
		this.playerRect = new Rectangle2D.Double(this.posX, this.posY, this.width, this.height);
	}
	
/**
 * Getters and Setters
 * @return
 * @param
 */
	
	public int getTicksInWallJump() {
		return ticksLeftInWallJump;
	}
	
	
	public Rectangle2D.Double getPlayerRect() {
		return playerRect;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public int getNumDashes() {
		return numDashes;
	}
	public void setNumDashes(int numDashes) {
		this.numDashes = numDashes;
	}
	public int getVelX() {
		return this.velX;
	}
	public int getPosX() {
		return posX;
	}
	public int getPosY() {
		return posY;
	}
	public int getVelY() {
		return velY;
	}

	public void setPosX(double d) {
		this.posX = (int) d;
		this.updatePlayerRect();
	}
	public void setPosY(double posY) {
		this.posY = (int) posY;
		this.updatePlayerRect();
	}

	public void kill() {
		this.hasDied  = true;
	}

	public boolean hasDied() {
		return this.hasDied;
	}
	
	public void setVelX(int i) {
		this.velX = i;
	}

	public void setVelY(int i) {
		this.velY = i;
		
	}

	public void canJump() {
		this.canJump = true;
	}

	public void dashLeft() {
		this.velX = -DASH_VELOCITY;
		this.dashYVel = 0;
	}
	
	public void dashRight() {
		this.velX = DASH_VELOCITY;
		this.dashYVel = 0;
	}

	public void dashDown() {
		this.dashYVel = DASH_VELOCITY;
	}
	public void dashUp() {
		this.dashYVel = -DASH_VELOCITY;
		
	}

	public boolean getLevel() {
		return this.level;
	}

	public void addDash() {
		this.numDashes+=1;
		
	}
	public void removeDash() {
		this.numDashes--;
	}

	public int getTicksInDash() {
		return ticksLeftInDash;
	}

	public void cantJump() {
		this.canJump = false;
	}

	public void setJumpRight() {
		this.canJumpRight = true;
	}

	public void setJumpLeft() {
		this.canJumpLeft = true;
	}
}
