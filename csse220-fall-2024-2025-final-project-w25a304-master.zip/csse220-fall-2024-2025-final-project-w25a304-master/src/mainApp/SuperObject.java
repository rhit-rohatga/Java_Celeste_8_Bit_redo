package mainApp;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

/**
 * Class SuperObject
 * @author rohatga
 * Purpose:
 * 		Stores the information relevent to all the subclasses in Interactable and LevelObjects:
 * 		Defines the methods that need to be implemented by either LevelObjects or Interactable
 * Restrictions:
 * 		abstract class
 * 		not much functionality
 */
public abstract class SuperObject {
	private int rectX;
	private int rectY;
	private int width;
	private int height;
	private Rectangle2D.Double rectangle;
	
	/**
	 * Constructor that stores the Rectangle, left corner point, width and height as fields
	 * @param objectRectangle
	 */
	public SuperObject(Rectangle2D.Double objectRectangle) {
		this.rectangle = objectRectangle;
		this.rectX = (int) this.rectangle.getX();
		this.rectY = (int) this.rectangle.getY();
		this.width = (int) objectRectangle.width;
		this.height = (int) objectRectangle.height;
	}
	
	/**
	 * Collision method, calls all the subclass methods that enable unique functionality upon collision
	 */
	public abstract void collideWithPlayer(Player player);
	
	
	/**
	 * Checks if the player collides with the SuperObject in question and then calls the abstract collideWithPlayer method
	 * @param player
	 */
	public void doesCollide(Player player) {
		if(this.rectangle.intersects(player.getPlayerRect())){
			collideWithPlayer(player);
		}
	}
	
	public Rectangle2D.Double getRectangle() {
		return rectangle;
	}
	
	public void updateRectangle() {
		this.rectangle = new Rectangle2D.Double(rectX, rectY, this.width, this.height);
	}
	
	/**
	 * Changes the x position of the cloud and the flying strawberry, if implemented
	 * @param x
	 */
	public void addX(int x) {
		this.rectX += x;
		this.updateRectangle();
	}
	
	/**
	 * Checks if the object is offscreen and brings it back onto the screen on the other side. 
	 */
	public void isOffScreen() {
		if(this.rectX > MainApp.WIDTH) {
			this.rectX = 0;
		}else if(this.rectX < 0) {
			this.rectX = MainApp.WIDTH ;
		}
	}
	public void drawOn(Graphics2D g) {
		g.draw(rectangle);
		g.fill(rectangle);
	}
}
	