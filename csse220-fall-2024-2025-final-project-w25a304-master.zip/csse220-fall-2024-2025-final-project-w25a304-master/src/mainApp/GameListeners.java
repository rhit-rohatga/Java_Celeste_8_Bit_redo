package mainApp;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Class: GameListeners
 * @author rohatga, cravenbe
 * <br> Purpose: Detect key presses and update the game every tick
 * <br> Restrictions: 
 * <br> 	Can only make one of 3 listeners, more can be added
 * <br> 	Need getters to add the other listeners
 */
public class GameListeners {
	private Player player;
	private GameComponent component;
	private Overlay overlay;
	private boolean rDown;
	private boolean lDown;
	private boolean dDown;
	private boolean uDown;

	/**
	 * @param component
	 * gets the player and overlay from component
	 * saves the player, and overlay as fields
	 */
	public GameListeners(GameComponent component) {
		this.component = component;
		this.player = component.getPlayer();
		this.overlay = component.getOverlay();
	}	
	
	/**
	 * Class MovementListener
	 * @author rohatga, cravenbe
	 * 
	 * <br> Purpose:Detects the keys for player movement and acts accordingly
	 * <br> Example:
	 * 			if w or up-arrow-key was pressed, it points the player upwards
	 * 			if a or left-arrow-key was pressed, it changes the player velocity to be leftwards.
	 * <br> Similarly for all the other arrow/wasd keys.
	 * <br> Spacebar is jump, X is dash
	 */
	class MovementListener implements KeyListener{

		@Override
		public void keyTyped(KeyEvent e) {}

		@Override
		public void keyPressed(KeyEvent e) {

			if(e.getKeyCode() == 37 || Character.toLowerCase(e.getKeyChar()) == 'a') {
				lDown = true;
			}
			
			if(e.getKeyCode() == 39 || Character.toLowerCase(e.getKeyChar()) == 'd') {
				rDown = true;
			}
			
			if(e.getKeyCode() == 38 || Character.toLowerCase(e.getKeyChar()) == 'w') {
				uDown = true;
			}
			if(e.getKeyCode() == 40 || Character.toLowerCase(e.getKeyChar()) == 's') {
				dDown = true;
			}
			
			if(e.getKeyChar() == ' ') {
				player.jump();
			}
			
			if(e.getKeyChar() == 'x' && player.getNumDashes() >=1) {
				player.dashHandler();

				if(player.directionOfXMovement() == "left") {
					player.dashLeft();
				}
				if(player.directionOfXMovement() == "right") {
					player.dashRight();
				}
				if(uDown == true) {
					player.dashUp();
				}
				if(dDown == true) {
					player.dashDown();
				}
			}
			
			if(e.getKeyChar() == 'z') {
				player.jump();
			}
		}

		@Override
		public void keyReleased(KeyEvent e) {

			if(e.getKeyCode() == 37 || Character.toLowerCase(e.getKeyChar()) == 'a') {
				lDown = false;
			}

			if(e.getKeyCode() == 39  || Character.toLowerCase(e.getKeyChar()) == 'd') {
				rDown = false;
			}
			
			if(e.getKeyCode() == 38 || Character.toLowerCase(e.getKeyChar()) == 'w') {
				uDown = false;
			}
			
			if(e.getKeyCode() == 40 || Character.toLowerCase(e.getKeyChar()) == 's') {
				dDown = false;
			}
		}
	}
	
	/**
	 * Class GameAdvanceListener
	 * @author rohatga, cravenbe
	 * 
	 * <br> Purpose: 
	 * 		Updates the entire game, calling many methods in component and player:
	 * 		Checks if the level is complete, or if the player has died
	 * <br> Example:
	 * 			update state loops through all the moving classes and updates their positions based on their velocity
	 * 			handle collisions checks if any of the moving classes have collided, and calls the method in LevelObjects to fix the position
	 * 			reload just redraws the screen
	 * <br> Dash code is in here because dash functions based on ticks outside of the regular updatePlayerPos method
	 */
	class GameAdvanceListener implements ActionListener {
		boolean inSpecialLevel = false;
		@Override
		public void actionPerformed(ActionEvent e) {
			advanceOneTick();
		}

		public void advanceOneTick() {
			player = component.getPlayer();
			player.cantJump();
			if(player.getLevel()) {
				overlay.toNextLevel();
			}
			if(player.hasDied()) {
				overlay.reload();
			}
			if(overlay.getIndex() == 0) {
				if(player.getPosX() <= 80 && player.getPosY() <= 270 && player.getPosY()>=180 && !inSpecialLevel) {
					overlay.loadSpecialLevel();
					inSpecialLevel = true;
				}
				if(inSpecialLevel) {
					if(player.getPosX() >= 700 && player.getPosY() <= 700 && player.getPosY()>= 550) {
						overlay.reload();
					}
				}
			}
			if(player.getTicksInDash() <= 0) {
				if(rDown == true && lDown == true) {
					player.setVelX(0);
				}else if(rDown == true) {
					player.moveRight();
				} else if(lDown == true) {
					player.moveLeft();
				} else {
					player.setVelX(0);
				}
			}
			component.handleCollisions();
			component.updateState();
			component.repaint();
		}
	}
	
	/**
	 * Class levelSelectListener
	 * @author rohatga
	 * Changes the levels based on whether the n (next) key or p (previous) keys are pressed
	 * moves to the next level if n is pressed
	 * moves to the previous level if p is pressed
	 */
	class LevelSelectListener implements KeyListener{

		@Override
		public void keyTyped(KeyEvent e) {}
		
		@Override
		public void keyPressed(KeyEvent e) {
			if(e.getKeyChar() == 'n') {
				overlay.toNextLevel();
			}
		}

		@Override
		public void keyReleased(KeyEvent e) {
			if(e.getKeyChar() == 'p') {
				overlay.toPreviousLevel();
			}
		}
		
	}
	
	public MovementListener makeKeyListener() {
		return new MovementListener();
	}
	public GameAdvanceListener makeTimeListener() {
		return new GameAdvanceListener();
	}
	public LevelSelectListener makeLevelListener() {
		return new LevelSelectListener();
	}
	
}	
	
