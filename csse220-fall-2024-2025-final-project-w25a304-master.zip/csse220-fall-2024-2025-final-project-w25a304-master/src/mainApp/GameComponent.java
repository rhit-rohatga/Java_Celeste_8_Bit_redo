package mainApp;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComponent;
import interactable.Interactable;
import baseObject.Cloud;
import baseObject.LevelObjects;

/**
 * Class: GameComponent
 * @author rohatga
 * <br> Purpose: draw and update the game
 * <br> It is a subclass of JComponent
 * <br> Restrictions: 
 * <br> 	Can't create blocks
 * <br> 	Doesn't create the level
 * <br> 	Creates an instance of the Overlay class to load the game.
 * <br> 	Loads the first level instantly upon being created 
 * <br> 	Updates and draws the game once every tick
 */
public class GameComponent extends JComponent{
	private List<Interactable> interactables = new ArrayList<>();
	private Player player;
	public static final int DELAY = 20;
	private ArrayList<LevelObjects> blocks;
	private Overlay overlay = new Overlay(this);
	private ArrayList<Cloud> clouds;
	
	/**
	 * Uses a method in the overlay to create all the objects at their defined positions
	 * <br> Restrictions:
	 * <br> 	Only loads the first level
	 */
	public GameComponent() {
		try {
			overlay.loadLevel("");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param Graphics
	 * <br> Creates an instance of Graphics2D to draw the Rectangle2Ds
	 * <br> Calls a method in GameComponent that draws all the objects
	 */
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D) g;
		this.draw(g2);
	}
	
	/**
	 * Calls individual methods in Cloud and Player to update their velocities and then positions
	 * Calls a method in GameComponent that handles all the times player collides with another object
	 * 
	 */
	public void updateState() {
		if(this.overlay.getIndex() == 6) {
			for(Cloud cloud: clouds) {
				cloud.updatePos();
			}
		}
		this.player.ticksHandler(); // updates Dash
		this.player.updatePos(); // updates position using velocities
		this.handleCollisions(); // calls handle collision
		this.repaint(); // redraws the screen
	}
	
	/**
	 * goes through every SuperObject and checks if it collides with Player
	 * Calls the handleCollision methods in each class that collides
	 */
	public void handleCollisions() {
		try{
			for (LevelObjects block : blocks) {
				block.doesCollide(player);
			}
			for(Interactable thing: interactables) {
				thing.doesCollide(player);
			}
			if(overlay.getIndex() == 6) { // checks if the level has clouds or not
				for(Cloud cloud: clouds) {
					cloud.doesCollide(player);
				}
			}
		}catch(NullPointerException a) {
			System.err.println("List not loaded correctly from overlay, a list is null");
		}
		
		 
	}
	
	/**
	 * Calls the individual drawOn methods in each class.
	 * @param g
	 */
	public void draw(Graphics2D g) {
		player.drawOn(g);
		if(overlay.getIndex() ==6) {
			for (Cloud cloud : clouds) {
				cloud.drawOn(g);
			}
		}
		for (LevelObjects block : blocks) {
			block.drawOn(g);
		}
		for (Interactable thing: interactables) {
			thing.drawOn(g);
		}
	}
/**
 * Getters and Setters
 * @return
 */
	public Player getPlayer() {
		return player;
	}

	public Overlay getOverlay() {
		return overlay;
	}
	
/**
 * Called by Overlay to tell the Component what all to draw
 * @param player, List<Interactable>, List<LevelObjects>, List<Clouds>
 */
	
	public void setPlayer(Player player) {
		this.player = player;
	}
	public void setInteractables(List<Interactable> interactables) {
		this.interactables = interactables;
	}

	public void setblockList(ArrayList<LevelObjects> blocks) {
		this.blocks = blocks;
	}

	public void setCloudList(ArrayList<Cloud> clouds) {
		this.clouds = clouds;
		
	}
	
	
}
